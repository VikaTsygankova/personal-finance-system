package com.finance.app.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Transaction {
    private String id;
    private TransactionType type;
    private String category;
    private double amount;
    private LocalDateTime timestamp;
    private String description;

    public Transaction(TransactionType type, String category, double amount, String description) {
        this.id = java.util.UUID.randomUUID().toString();
        this.type = type;
        this.category = category;
        this.amount = amount;
        this.timestamp = LocalDateTime.now();
        this.description = description;
    }

    public Transaction(String id, TransactionType type, String category, double amount, 
                      LocalDateTime timestamp, String description) {
        this.id = id;
        this.type = type;
        this.category = category;
        this.amount = amount;
        this.timestamp = timestamp;
        this.description = description;
    }

    public String getId() {
        return id;
    }

    public TransactionType getType() {
        return type;
    }

    public String getCategory() {
        return category;
    }

    public double getAmount() {
        return amount;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public String getDescription() {
        return description;
    }

    @Override
    public String toString() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return String.format("%s: %s - %.2f (%s) [%s]", 
            type, category, amount, description, timestamp.format(formatter));
    }

    public enum TransactionType {
        INCOME("Доход"),
        EXPENSE("Расход");

        private final String displayName;

        TransactionType(String displayName) {
            this.displayName = displayName;
        }

        public String getDisplayName() {
            return displayName;
        }
    }
}


