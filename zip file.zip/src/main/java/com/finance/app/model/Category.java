package com.finance.app.model;

public class Category {
    private String name;
    private double budget;

    public Category(String name) {
        this.name = name;
        this.budget = 0.0;
    }

    public Category(String name, double budget) {
        this.name = name;
        this.budget = budget;
    }

    public String getName() {
        return name;
    }

    public double getBudget() {
        return budget;
    }

    public void setBudget(double budget) {
        this.budget = budget;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Category category = (Category) obj;
        return name != null && name.equalsIgnoreCase(category.name);
    }

    @Override
    public int hashCode() {
        return name != null ? name.toLowerCase().hashCode() : 0;
    }

    @Override
    public String toString() {
        return String.format("Категория: %s, Бюджет: %.2f", name, budget);
    }
}


