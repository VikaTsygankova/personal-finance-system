package com.finance.app.model;

import java.util.*;

public class Wallet {
    private String userId;
    private List<Transaction> transactions;
    private Map<String, Category> categories;
    private double balance;

    public Wallet(String userId) {
        this.userId = userId;
        this.transactions = new ArrayList<>();
        this.categories = new HashMap<>();
        this.balance = 0.0;
    }

    public String getUserId() {
        return userId;
    }

    public List<Transaction> getTransactions() {
        return new ArrayList<>(transactions);
    }

    public Map<String, Category> getCategories() {
        return new HashMap<>(categories);
    }

    public double getBalance() {
        return balance;
    }

    public void addTransaction(Transaction transaction) {
        transactions.add(transaction);
        if (transaction.getType() == Transaction.TransactionType.INCOME) {
            balance += transaction.getAmount();
        } else {
            balance -= transaction.getAmount();
        }
    }

    public void addCategory(String categoryName) {
        if (!categories.containsKey(categoryName.toLowerCase())) {
            categories.put(categoryName.toLowerCase(), new Category(categoryName));
        }
    }

    public void setBudget(String categoryName, double budget) {
        String key = categoryName.toLowerCase();
        if (categories.containsKey(key)) {
            categories.get(key).setBudget(budget);
        } else {
            Category category = new Category(categoryName, budget);
            categories.put(key, category);
        }
    }

    public Category getCategory(String categoryName) {
        return categories.get(categoryName.toLowerCase());
    }

    public boolean hasCategory(String categoryName) {
        return categories.containsKey(categoryName.toLowerCase());
    }

    public double getTotalIncome() {
        return transactions.stream()
                .filter(t -> t.getType() == Transaction.TransactionType.INCOME)
                .mapToDouble(Transaction::getAmount)
                .sum();
    }

    public double getTotalExpenses() {
        return transactions.stream()
                .filter(t -> t.getType() == Transaction.TransactionType.EXPENSE)
                .mapToDouble(Transaction::getAmount)
                .sum();
    }

    public double getIncomeByCategory(String categoryName) {
        return transactions.stream()
                .filter(t -> t.getType() == Transaction.TransactionType.INCOME)
                .filter(t -> t.getCategory().equalsIgnoreCase(categoryName))
                .mapToDouble(Transaction::getAmount)
                .sum();
    }

    public double getExpensesByCategory(String categoryName) {
        return transactions.stream()
                .filter(t -> t.getType() == Transaction.TransactionType.EXPENSE)
                .filter(t -> t.getCategory().equalsIgnoreCase(categoryName))
                .mapToDouble(Transaction::getAmount)
                .sum();
    }

    public double getExpensesByCategories(List<String> categoryNames) {
        Set<String> lowerCaseCategories = new HashSet<>();
        for (String cat : categoryNames) {
            lowerCaseCategories.add(cat.toLowerCase());
        }
        
        return transactions.stream()
                .filter(t -> t.getType() == Transaction.TransactionType.EXPENSE)
                .filter(t -> lowerCaseCategories.contains(t.getCategory().toLowerCase()))
                .mapToDouble(Transaction::getAmount)
                .sum();
    }

    public Map<String, Double> getIncomeByCategories() {
        Map<String, Double> result = new HashMap<>();
        transactions.stream()
                .filter(t -> t.getType() == Transaction.TransactionType.INCOME)
                .forEach(t -> {
                    String cat = t.getCategory();
                    result.put(cat, result.getOrDefault(cat, 0.0) + t.getAmount());
                });
        return result;
    }

    public Map<String, Double> getExpensesByCategories() {
        Map<String, Double> result = new HashMap<>();
        transactions.stream()
                .filter(t -> t.getType() == Transaction.TransactionType.EXPENSE)
                .forEach(t -> {
                    String cat = t.getCategory();
                    result.put(cat, result.getOrDefault(cat, 0.0) + t.getAmount());
                });
        return result;
    }

    public double getRemainingBudget(String categoryName) {
        Category category = getCategory(categoryName);
        if (category == null) {
            return 0.0;
        }
        double spent = getExpensesByCategory(categoryName);
        return category.getBudget() - spent;
    }

    public Map<String, Double> getAllRemainingBudgets() {
        Map<String, Double> result = new HashMap<>();
        for (Category category : categories.values()) {
            if (category.getBudget() > 0) {
                result.put(category.getName(), getRemainingBudget(category.getName()));
            }
        }
        return result;
    }

    public List<String> getMissingCategories(List<String> categoryNames) {
        List<String> missing = new ArrayList<>();
        for (String cat : categoryNames) {
            if (!hasCategory(cat)) {
                missing.add(cat);
            }
        }
        return missing;
    }
}


