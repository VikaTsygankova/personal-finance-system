package com.finance.app;

import com.finance.app.cli.CLIInterface;

public class Main {
    public static void main(String[] args) {
        CLIInterface cli = new CLIInterface();
        cli.start();
    }
}


