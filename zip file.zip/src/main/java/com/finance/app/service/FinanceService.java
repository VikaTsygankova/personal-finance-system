package com.finance.app.service;

import com.finance.app.model.*;
import java.util.*;

public class FinanceService {
    private AuthService authService;

    public FinanceService(AuthService authService) {
        this.authService = authService;
    }

    public boolean addIncome(String category, double amount, String description) {
        if (!authService.isLoggedIn()) {
            return false;
        }
        if (amount <= 0) {
            return false;
        }
        if (category == null || category.trim().isEmpty()) {
            return false;
        }
        
        Wallet wallet = authService.getCurrentUser().getWallet();
        wallet.addCategory(category);
        Transaction transaction = new Transaction(
            Transaction.TransactionType.INCOME, 
            category, 
            amount, 
            description != null ? description : ""
        );
        wallet.addTransaction(transaction);
        return true;
    }

    public boolean addExpense(String category, double amount, String description) {
        if (!authService.isLoggedIn()) {
            return false;
        }
        if (amount <= 0) {
            return false;
        }
        if (category == null || category.trim().isEmpty()) {
            return false;
        }
        
        Wallet wallet = authService.getCurrentUser().getWallet();
        wallet.addCategory(category);
        Transaction transaction = new Transaction(
            Transaction.TransactionType.EXPENSE, 
            category, 
            amount, 
            description != null ? description : ""
        );
        wallet.addTransaction(transaction);
        checkBudgetExceeded(category);
        checkOverExpenditure();
        return true;
    }

    public boolean setBudget(String category, double budget) {
        if (!authService.isLoggedIn()) {
            return false;
        }
        if (budget < 0) {
            return false;
        }
        if (category == null || category.trim().isEmpty()) {
            return false;
        }
        
        Wallet wallet = authService.getCurrentUser().getWallet();
        wallet.setBudget(category, budget);
        return true;
    }

    public double calculateTotalIncome() {
        if (!authService.isLoggedIn()) {
            return 0.0;
        }
        return authService.getCurrentUser().getWallet().getTotalIncome();
    }

    public double calculateTotalExpenses() {
        if (!authService.isLoggedIn()) {
            return 0.0;
        }
        return authService.getCurrentUser().getWallet().getTotalExpenses();
    }

    public double calculateByCategory(String category, Transaction.TransactionType type) {
        if (!authService.isLoggedIn()) {
            return 0.0;
        }
        Wallet wallet = authService.getCurrentUser().getWallet();
        if (type == Transaction.TransactionType.INCOME) {
            return wallet.getIncomeByCategory(category);
        } else {
            return wallet.getExpensesByCategory(category);
        }
    }

    public double calculateByCategories(List<String> categories) {
        if (!authService.isLoggedIn()) {
            return 0.0;
        }
        Wallet wallet = authService.getCurrentUser().getWallet();
        List<String> missing = wallet.getMissingCategories(categories);
        if (!missing.isEmpty()) {
            throw new IllegalArgumentException("Категории не найдены: " + String.join(", ", missing));
        }
        return wallet.getExpensesByCategories(categories);
    }

    public Map<String, Double> getIncomeByCategories() {
        if (!authService.isLoggedIn()) {
            return new HashMap<>();
        }
        return authService.getCurrentUser().getWallet().getIncomeByCategories();
    }

    public Map<String, Double> getExpensesByCategories() {
        if (!authService.isLoggedIn()) {
            return new HashMap<>();
        }
        return authService.getCurrentUser().getWallet().getExpensesByCategories();
    }

    public Map<String, Double> getBudgetsWithRemaining() {
        if (!authService.isLoggedIn()) {
            return new HashMap<>();
        }
        Wallet wallet = authService.getCurrentUser().getWallet();
        return wallet.getAllRemainingBudgets();
    }

    public boolean transfer(String toUsername, double amount, String description) {
        if (!authService.isLoggedIn()) {
            return false;
        }
        if (amount <= 0) {
            return false;
        }
        User currentUser = authService.getCurrentUser();
        if (currentUser.getUsername().equalsIgnoreCase(toUsername)) {
            return false;
        }
        
        User recipient = authService.getUser(toUsername);
        if (recipient == null) {
            return false;
        }
        
        Wallet senderWallet = currentUser.getWallet();
        if (senderWallet.getBalance() < amount) {
            return false;
        }
        
        Transaction expense = new Transaction(
            Transaction.TransactionType.EXPENSE,
            "Перевод",
            amount,
            "Перевод пользователю: " + toUsername + (description != null ? " (" + description + ")" : "")
        );
        senderWallet.addTransaction(expense);
        
        Transaction income = new Transaction(
            Transaction.TransactionType.INCOME,
            "Перевод",
            amount,
            "Перевод от пользователя: " + currentUser.getUsername() + (description != null ? " (" + description + ")" : "")
        );
        recipient.getWallet().addTransaction(income);
        
        return true;
    }

    private void checkBudgetExceeded(String category) {
        Wallet wallet = authService.getCurrentUser().getWallet();
        Category cat = wallet.getCategory(category);
        if (cat != null && cat.getBudget() > 0) {
            double remaining = wallet.getRemainingBudget(category);
            if (remaining < 0) {
                System.out.println("⚠️  ВНИМАНИЕ: Превышен лимит бюджета для категории '" + category + 
                    "'. Превышение: " + String.format("%.2f", Math.abs(remaining)));
            }
        }
    }

    private void checkOverExpenditure() {
        Wallet wallet = authService.getCurrentUser().getWallet();
        double totalIncome = wallet.getTotalIncome();
        double totalExpenses = wallet.getTotalExpenses();
        if (totalExpenses > totalIncome) {
            System.out.println("⚠️  ВНИМАНИЕ: Расходы превысили доходы! Перерасход: " + 
                String.format("%.2f", totalExpenses - totalIncome));
        }
    }

    public void checkBudgetWarnings() {
        if (!authService.isLoggedIn()) {
            return;
        }
        Wallet wallet = authService.getCurrentUser().getWallet();
        for (Category category : wallet.getCategories().values()) {
            if (category.getBudget() > 0) {
                double remaining = wallet.getRemainingBudget(category.getName());
                double percentage = (category.getBudget() - remaining) / category.getBudget() * 100;
                if (percentage >= 80 && percentage < 100) {
                    System.out.println("⚠️  Предупреждение: Бюджет категории '" + category.getName() + 
                        "' использован на " + String.format("%.1f", percentage) + "%");
                }
            }
        }
    }
}


