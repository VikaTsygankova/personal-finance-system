package com.finance.app.service;

import com.finance.app.model.User;
import java.util.*;

public class AuthService {
    private Map<String, User> users;
    private User currentUser;

    public AuthService() {
        this.users = new HashMap<>();
        this.currentUser = null;
    }

    public boolean register(String username, String password) {
        if (username == null || username.trim().isEmpty()) {
            return false;
        }
        if (password == null || password.trim().isEmpty()) {
            return false;
        }
        String key = username.toLowerCase();
        if (users.containsKey(key)) {
            return false;
        }
        users.put(key, new User(username, password));
        return true;
    }

    public boolean login(String username, String password) {
        if (username == null || password == null) {
            return false;
        }
        String key = username.toLowerCase();
        User user = users.get(key);
        if (user != null && user.checkPassword(password)) {
            currentUser = user;
            return true;
        }
        return false;
    }

    public void logout() {
        currentUser = null;
    }

    public boolean isLoggedIn() {
        return currentUser != null;
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public void setUsers(Map<String, User> users) {
        this.users = users;
    }

    public Map<String, User> getUsers() {
        return new HashMap<>(users);
    }

    public User getUser(String username) {
        return users.get(username.toLowerCase());
    }
}


