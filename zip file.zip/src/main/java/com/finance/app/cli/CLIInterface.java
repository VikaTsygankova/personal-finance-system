package com.finance.app.cli;

import com.finance.app.model.Transaction;
import com.finance.app.service.AuthService;
import com.finance.app.service.FinanceService;
import com.finance.app.storage.DataStorage;

import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class CLIInterface {
    private AuthService authService;
    private FinanceService financeService;
    private DataStorage dataStorage;
    private Scanner scanner;
    private boolean running;

    public CLIInterface() {
        this.authService = new AuthService();
        this.financeService = new FinanceService(authService);
        this.dataStorage = new DataStorage();
        this.scanner = new Scanner(System.in);
        this.running = true;
        
        Map<String, com.finance.app.model.User> users = dataStorage.loadUsers();
        authService.setUsers(users);
        for (com.finance.app.model.User user : users.values()) {
            com.finance.app.model.Wallet wallet = dataStorage.loadWallet(user.getUsername());
            user.setWallet(wallet);
        }
    }

    public void start() {
        System.out.println("=== Система управления личными финансами ===");
        System.out.println("Введите 'help' для просмотра доступных команд");
        System.out.println();

        while (running) {
            if (!authService.isLoggedIn()) {
                showAuthMenu();
            } else {
                showMainMenu();
            }
        }
    }

    private void showAuthMenu() {
        System.out.print("Выберите действие (login/register/exit): ");
        String command = scanner.nextLine().trim().toLowerCase();

        switch (command) {
            case "login":
                handleLogin();
                break;
            case "register":
                handleRegister();
                break;
            case "exit":
                handleExit();
                break;
            default:
                System.out.println("Неизвестная команда. Используйте: login, register или exit");
        }
    }

    private void showMainMenu() {
        System.out.print("> ");
        String input = scanner.nextLine().trim();
        if (input.isEmpty()) {
            return;
        }

        String[] parts = input.split("\\s+", 2);
        String command = parts[0].toLowerCase();
        String args = parts.length > 1 ? parts[1] : "";

        switch (command) {
            case "help":
                showHelp();
                break;
            case "income":
                handleAddIncome(args);
                break;
            case "expense":
                handleAddExpense(args);
                break;
            case "budget":
                handleSetBudget(args);
                break;
            case "stats":
                showStatistics();
                break;
            case "balance":
                showBalance();
                break;
            case "transfer":
                handleTransfer(args);
                break;
            case "export":
                handleExport(args);
                break;
            case "logout":
                handleLogout();
                break;
            case "exit":
                handleExit();
                break;
            default:
                System.out.println("Неизвестная команда. Введите 'help' для справки.");
        }
    }

    private void handleLogin() {
        System.out.print("Логин: ");
        String username = scanner.nextLine().trim();
        System.out.print("Пароль: ");
        String password = scanner.nextLine().trim();

        if (authService.login(username, password)) {
            com.finance.app.model.User user = authService.getCurrentUser();
            com.finance.app.model.Wallet wallet = dataStorage.loadWallet(user.getUsername());
            user.setWallet(wallet);
            System.out.println("✓ Успешный вход! Добро пожаловать, " + username);
            financeService.checkBudgetWarnings();
        } else {
            System.out.println("✗ Ошибка: Неверный логин или пароль");
        }
    }

    private void handleRegister() {
        System.out.print("Логин: ");
        String username = scanner.nextLine().trim();
        if (username.isEmpty()) {
            System.out.println("✗ Ошибка: Логин не может быть пустым");
            return;
        }
        System.out.print("Пароль: ");
        String password = scanner.nextLine().trim();
        if (password.isEmpty()) {
            System.out.println("✗ Ошибка: Пароль не может быть пустым");
            return;
        }

        if (authService.register(username, password)) {
            System.out.println("✓ Пользователь успешно зарегистрирован!");
            authService.login(username, password);
        } else {
            System.out.println("✗ Ошибка: Пользователь с таким логином уже существует");
        }
    }

    private void handleAddIncome(String args) {
        try {
            String[] parts = parseTransactionArgs(args);
            if (parts == null) return;

            String category = parts[0];
            double amount = Double.parseDouble(parts[1]);
            String description = parts.length > 2 ? parts[2] : "";

            if (financeService.addIncome(category, amount, description)) {
                System.out.println("✓ Доход добавлен: " + category + " - " + amount);
            } else {
                System.out.println("✗ Ошибка: Не удалось добавить доход. Проверьте данные.");
            }
        } catch (NumberFormatException e) {
            System.out.println("✗ Ошибка: Неверный формат суммы");
        } catch (Exception e) {
            System.out.println("✗ Ошибка: " + e.getMessage());
        }
    }

    private void handleAddExpense(String args) {
        try {
            String[] parts = parseTransactionArgs(args);
            if (parts == null) return;

            String category = parts[0];
            double amount = Double.parseDouble(parts[1]);
            String description = parts.length > 2 ? parts[2] : "";

            if (financeService.addExpense(category, amount, description)) {
                System.out.println("✓ Расход добавлен: " + category + " - " + amount);
            } else {
                System.out.println("✗ Ошибка: Не удалось добавить расход. Проверьте данные.");
            }
        } catch (NumberFormatException e) {
            System.out.println("✗ Ошибка: Неверный формат суммы");
        } catch (Exception e) {
            System.out.println("✗ Ошибка: " + e.getMessage());
        }
    }

    private void handleSetBudget(String args) {
        try {
            String[] parts = args.split("\\s+", 2);
            if (parts.length < 2) {
                System.out.println("✗ Ошибка: Используйте: budget <категория> <сумма>");
                return;
            }

            String category = parts[0];
            double budget = Double.parseDouble(parts[1]);

            if (financeService.setBudget(category, budget)) {
                System.out.println("✓ Бюджет установлен: " + category + " - " + budget);
            } else {
                System.out.println("✗ Ошибка: Не удалось установить бюджет");
            }
        } catch (NumberFormatException e) {
            System.out.println("✗ Ошибка: Неверный формат суммы");
        }
    }

    private void handleTransfer(String args) {
        try {
            String[] parts = args.split("\\s+", 2);
            if (parts.length < 2) {
                System.out.println("✗ Ошибка: Используйте: transfer <логин_получателя> <сумма> [описание]");
                return;
            }

            String toUsername = parts[0];
            String[] amountParts = parts[1].split("\\s+", 2);
            double amount = Double.parseDouble(amountParts[0]);
            String description = amountParts.length > 1 ? amountParts[1] : "";

            if (financeService.transfer(toUsername, amount, description)) {
                System.out.println("✓ Перевод выполнен: " + amount + " пользователю " + toUsername);
            } else {
                System.out.println("✗ Ошибка: Не удалось выполнить перевод. Проверьте баланс и логин получателя.");
            }
        } catch (NumberFormatException e) {
            System.out.println("✗ Ошибка: Неверный формат суммы");
        } catch (Exception e) {
            System.out.println("✗ Ошибка: " + e.getMessage());
        }
    }

    private String[] parseTransactionArgs(String args) {
        if (args.isEmpty()) {
            System.out.println("✗ Ошибка: Используйте: <команда> <категория> <сумма> [описание]");
            return null;
        }
        String[] parts = args.split("\\s+", 3);
        if (parts.length < 2) {
            System.out.println("✗ Ошибка: Укажите категорию и сумму");
            return null;
        }
        return parts;
    }

    private void showStatistics() {
        double totalIncome = financeService.calculateTotalIncome();
        double totalExpenses = financeService.calculateTotalExpenses();

        System.out.println("\n=== Статистика ===");
        System.out.println("Общий доход: " + String.format("%.2f", totalIncome));
        System.out.println("Общие расходы: " + String.format("%.2f", totalExpenses));
        System.out.println("Баланс: " + String.format("%.2f", totalIncome - totalExpenses));

        Map<String, Double> incomeByCat = financeService.getIncomeByCategories();
        if (!incomeByCat.isEmpty()) {
            System.out.println("\nДоходы по категориям:");
            for (Map.Entry<String, Double> entry : incomeByCat.entrySet()) {
                System.out.println("  " + entry.getKey() + ": " + String.format("%.2f", entry.getValue()));
            }
        }

        Map<String, Double> expensesByCat = financeService.getExpensesByCategories();
        if (!expensesByCat.isEmpty()) {
            System.out.println("\nРасходы по категориям:");
            for (Map.Entry<String, Double> entry : expensesByCat.entrySet()) {
                System.out.println("  " + entry.getKey() + ": " + String.format("%.2f", entry.getValue()));
            }
        }

        Map<String, Double> budgets = financeService.getBudgetsWithRemaining();
        if (!budgets.isEmpty()) {
            System.out.println("\nБюджет по категориям:");
            for (Map.Entry<String, Double> entry : budgets.entrySet()) {
                String category = entry.getKey();
                double remaining = entry.getValue();
                com.finance.app.model.Category cat = authService.getCurrentUser().getWallet().getCategory(category);
                if (cat != null) {
                    double budget = cat.getBudget();
                    System.out.println("  " + category + ": " + String.format("%.2f", budget) + 
                        ", Оставшийся бюджет: " + String.format("%.2f", remaining));
                }
            }
        }
        System.out.println();
    }

    private void showBalance() {
        com.finance.app.model.Wallet wallet = authService.getCurrentUser().getWallet();
        System.out.println("Текущий баланс: " + String.format("%.2f", wallet.getBalance()));
    }

    private void handleExport(String args) {
        if (args.isEmpty()) {
            args = "report.txt";
        }
        try (FileWriter writer = new FileWriter(args)) {
            writer.write("=== Отчет по финансам ===\n");
            writer.write("Пользователь: " + authService.getCurrentUser().getUsername() + "\n\n");

            double totalIncome = financeService.calculateTotalIncome();
            double totalExpenses = financeService.calculateTotalExpenses();

            writer.write("Общий доход: " + String.format("%.2f", totalIncome) + "\n");
            writer.write("Общие расходы: " + String.format("%.2f", totalExpenses) + "\n");
            writer.write("Баланс: " + String.format("%.2f", totalIncome - totalExpenses) + "\n\n");

            Map<String, Double> incomeByCat = financeService.getIncomeByCategories();
            if (!incomeByCat.isEmpty()) {
                writer.write("Доходы по категориям:\n");
                for (Map.Entry<String, Double> entry : incomeByCat.entrySet()) {
                    writer.write("  " + entry.getKey() + ": " + String.format("%.2f", entry.getValue()) + "\n");
                }
                writer.write("\n");
            }

            Map<String, Double> expensesByCat = financeService.getExpensesByCategories();
            if (!expensesByCat.isEmpty()) {
                writer.write("Расходы по категориям:\n");
                for (Map.Entry<String, Double> entry : expensesByCat.entrySet()) {
                    writer.write("  " + entry.getKey() + ": " + String.format("%.2f", entry.getValue()) + "\n");
                }
                writer.write("\n");
            }

            Map<String, Double> budgets = financeService.getBudgetsWithRemaining();
            if (!budgets.isEmpty()) {
                writer.write("Бюджет по категориям:\n");
                for (Map.Entry<String, Double> entry : budgets.entrySet()) {
                    String category = entry.getKey();
                    double remaining = entry.getValue();
                    com.finance.app.model.Category cat = authService.getCurrentUser().getWallet().getCategory(category);
                    if (cat != null) {
                        double budget = cat.getBudget();
                        writer.write("  " + category + ": " + String.format("%.2f", budget) + 
                            ", Оставшийся бюджет: " + String.format("%.2f", remaining) + "\n");
                    }
                }
            }

            System.out.println("✓ Отчет сохранен в файл: " + args);
        } catch (IOException e) {
            System.out.println("✗ Ошибка при сохранении отчета: " + e.getMessage());
        }
    }

    private void handleLogout() {
        saveCurrentUserData();
        authService.logout();
        System.out.println("✓ Вы вышли из системы");
    }

    private void handleExit() {
        if (authService.isLoggedIn()) {
            saveCurrentUserData();
        }
        saveAllUsers();
        System.out.println("До свидания!");
        running = false;
    }

    private void saveCurrentUserData() {
        com.finance.app.model.User user = authService.getCurrentUser();
        if (user != null) {
            dataStorage.saveWallet(user.getUsername(), user.getWallet());
        }
    }

    private void saveAllUsers() {
        dataStorage.saveUsers(authService.getUsers());
    }

    private void showHelp() {
        System.out.println("\n=== Доступные команды ===");
        System.out.println("До авторизации:");
        System.out.println("  login          - Войти в систему");
        System.out.println("  register       - Зарегистрироваться");
        System.out.println("  exit           - Выход из приложения");
        System.out.println("\nПосле авторизации:");
        System.out.println("  income <категория> <сумма> [описание]  - Добавить доход");
        System.out.println("  expense <категория> <сумма> [описание] - Добавить расход");
        System.out.println("  budget <категория> <сумма>              - Установить бюджет");
        System.out.println("  stats                                    - Показать статистику");
        System.out.println("  balance                                  - Показать баланс");
        System.out.println("  transfer <логин> <сумма> [описание]      - Перевод между пользователями");
        System.out.println("  export [имя_файла]                      - Экспорт отчета в файл");
        System.out.println("  logout                                   - Выйти из системы");
        System.out.println("  exit                                     - Выход из приложения");
        System.out.println("  help                                     - Показать эту справку");
        System.out.println("\nПримеры:");
        System.out.println("  income Зарплата 20000");
        System.out.println("  expense Еда 500 Покупка продуктов");
        System.out.println("  budget Еда 4000");
        System.out.println("  transfer user2 1000 Оплата за услугу");
        System.out.println();
    }
}


