package com.finance.app.storage;

import com.finance.app.model.*;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.lang.reflect.Type;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class DataStorage {
    private static final String DATA_DIR = "data";
    private static final String USERS_FILE = DATA_DIR + File.separator + "users.json";
    private Gson gson;

    public DataStorage() {
        gson = new GsonBuilder()
                .setPrettyPrinting()
                .registerTypeAdapter(LocalDateTime.class, new LocalDateTimeAdapter())
                .create();
        new File(DATA_DIR).mkdirs();
    }

    public void saveUsers(Map<String, User> users) {
        try (Writer writer = new FileWriter(USERS_FILE)) {
            Map<String, UserData> userDataMap = new HashMap<>();
            for (User user : users.values()) {
                UserData userData = new UserData();
                userData.username = user.getUsername();
                userData.password = user.getPassword();
                userDataMap.put(user.getUsername().toLowerCase(), userData);
                saveWallet(user.getUsername(), user.getWallet());
            }
            gson.toJson(userDataMap, writer);
        } catch (IOException e) {
            System.err.println("Ошибка при сохранении пользователей: " + e.getMessage());
        }
    }

    public Map<String, User> loadUsers() {
        Map<String, User> users = new HashMap<>();
        File file = new File(USERS_FILE);
        if (!file.exists()) {
            return users;
        }

        try (Reader reader = new FileReader(USERS_FILE)) {
            Type type = new TypeToken<Map<String, UserData>>(){}.getType();
            Map<String, UserData> userDataMap = gson.fromJson(reader, type);
            
            if (userDataMap != null) {
                for (UserData userData : userDataMap.values()) {
                    User user = new User(userData.username, userData.password != null ? userData.password : "");
                    Wallet wallet = loadWallet(userData.username);
                    user.setWallet(wallet);
                    users.put(user.getUsername().toLowerCase(), user);
                }
            }
        } catch (IOException e) {
            System.err.println("Ошибка при загрузке пользователей: " + e.getMessage());
        }
        return users;
    }

    public void saveWallet(String username, Wallet wallet) {
        try {
            File walletFile = new File(DATA_DIR + File.separator + username.toLowerCase() + "_wallet.json");
            try (Writer writer = new FileWriter(walletFile)) {
                gson.toJson(new WalletData(wallet), writer);
            }
        } catch (IOException e) {
            System.err.println("Ошибка при сохранении кошелька: " + e.getMessage());
        }
    }

    public Wallet loadWallet(String username) {
        File walletFile = new File(DATA_DIR + File.separator + username.toLowerCase() + "_wallet.json");
        if (!walletFile.exists()) {
            return new Wallet(username);
        }

        try (Reader reader = new FileReader(walletFile)) {
            WalletData walletData = gson.fromJson(reader, WalletData.class);
            if (walletData != null) {
                return walletData.toWallet(username);
            }
        } catch (IOException e) {
            System.err.println("Ошибка при загрузке кошелька: " + e.getMessage());
        }
        return new Wallet(username);
    }

    private static class UserData {
        String username;
        String password;
    }

    private static class WalletData {
        List<TransactionData> transactions;
        Map<String, CategoryData> categories;
        double balance;

        WalletData(Wallet wallet) {
            this.transactions = new ArrayList<>();
            for (Transaction t : wallet.getTransactions()) {
                this.transactions.add(new TransactionData(t));
            }
            this.categories = new HashMap<>();
            for (Category c : wallet.getCategories().values()) {
                this.categories.put(c.getName().toLowerCase(), new CategoryData(c));
            }
            this.balance = wallet.getBalance();
        }

        Wallet toWallet(String userId) {
            Wallet wallet = new Wallet(userId);
            for (CategoryData cd : categories.values()) {
                wallet.setBudget(cd.name, cd.budget);
            }
            for (TransactionData td : transactions) {
                Transaction t = td.toTransaction();
                wallet.addTransaction(t);
            }
            return wallet;
        }
    }

    private static class TransactionData {
        String id;
        String type;
        String category;
        double amount;
        String timestamp;
        String description;

        TransactionData(Transaction transaction) {
            this.id = transaction.getId();
            this.type = transaction.getType().name();
            this.category = transaction.getCategory();
            this.amount = transaction.getAmount();
            this.timestamp = transaction.getTimestamp().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
            this.description = transaction.getDescription();
        }

        Transaction toTransaction() {
            LocalDateTime time = LocalDateTime.parse(timestamp, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
            Transaction.TransactionType typeEnum = Transaction.TransactionType.valueOf(type);
            return new Transaction(id, typeEnum, category, amount, time, description);
        }
    }

    private static class CategoryData {
        String name;
        double budget;

        CategoryData(Category category) {
            this.name = category.getName();
            this.budget = category.getBudget();
        }
    }

    private static class LocalDateTimeAdapter implements com.google.gson.JsonSerializer<LocalDateTime>,
            com.google.gson.JsonDeserializer<LocalDateTime> {
        private static final DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

        @Override
        public com.google.gson.JsonElement serialize(LocalDateTime src, Type typeOfSrc,
                com.google.gson.JsonSerializationContext context) {
            return new com.google.gson.JsonPrimitive(formatter.format(src));
        }

        @Override
        public LocalDateTime deserialize(com.google.gson.JsonElement json, Type typeOfT,
                com.google.gson.JsonDeserializationContext context) {
            return LocalDateTime.parse(json.getAsString(), formatter);
        }
    }
}

