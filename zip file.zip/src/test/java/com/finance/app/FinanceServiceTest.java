package com.finance.app;

import com.finance.app.service.AuthService;
import com.finance.app.service.FinanceService;
import com.finance.app.model.Transaction;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;

/**
 * Тесты для класса FinanceService
 */
public class FinanceServiceTest {
    private AuthService authService;
    private FinanceService financeService;

    @BeforeEach
    void setUp() {
        authService = new AuthService();
        financeService = new FinanceService(authService);
        authService.register("testuser", "password");
        authService.login("testuser", "password");
    }

    @Test
    void testAddIncome() {
        assertTrue(financeService.addIncome("Зарплата", 1000.0, "Тест"));
        assertEquals(1000.0, financeService.calculateTotalIncome(), 0.01);
    }

    @Test
    void testAddExpense() {
        assertTrue(financeService.addExpense("Еда", 500.0, "Тест"));
        assertEquals(500.0, financeService.calculateTotalExpenses(), 0.01);
    }

    @Test
    void testAddIncomeWithoutLogin() {
        authService.logout();
        assertFalse(financeService.addIncome("Зарплата", 1000.0, ""));
    }

    @Test
    void testSetBudget() {
        assertTrue(financeService.setBudget("Еда", 1000.0));
        assertFalse(financeService.setBudget("Еда", -100.0)); // Отрицательный бюджет
    }

    @Test
    void testCalculateByCategory() {
        financeService.addIncome("Зарплата", 2000.0, "");
        financeService.addIncome("Зарплата", 3000.0, "");
        
        assertEquals(5000.0, 
            financeService.calculateByCategory("Зарплата", Transaction.TransactionType.INCOME), 0.01);
    }

    @Test
    void testCalculateByCategories() {
        financeService.addExpense("Еда", 300.0, "");
        financeService.addExpense("Развлечения", 500.0, "");
        
        List<String> categories = Arrays.asList("Еда", "Развлечения");
        assertEquals(800.0, financeService.calculateByCategories(categories), 0.01);
    }

    @Test
    void testCalculateByCategoriesWithMissing() {
        financeService.addExpense("Еда", 300.0, "");
        
        List<String> categories = Arrays.asList("Еда", "Несуществующая");
        assertThrows(IllegalArgumentException.class, 
            () -> financeService.calculateByCategories(categories));
    }

    @Test
    void testTransfer() {
        authService.register("user2", "password2");
        
        financeService.addIncome("Зарплата", 1000.0, "");
        assertTrue(financeService.transfer("user2", 500.0, "Тест"));
        
        assertEquals(500.0, financeService.calculateTotalExpenses(), 0.01);
        assertEquals(1000.0, financeService.calculateTotalIncome(), 0.01);
    }

    @Test
    void testTransferInsufficientFunds() {
        authService.register("user2", "password2");
        assertFalse(financeService.transfer("user2", 1000.0, ""));
    }

    @Test
    void testTransferToSelf() {
        assertFalse(financeService.transfer("testuser", 100.0, ""));
    }
}



