package com.finance.app;

import com.finance.app.model.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;

/**
 * Тесты для класса Wallet
 */
public class WalletTest {
    private Wallet wallet;

    @BeforeEach
    void setUp() {
        wallet = new Wallet("testuser");
    }

    @Test
    void testAddIncome() {
        Transaction income = new Transaction(
            Transaction.TransactionType.INCOME, "Зарплата", 1000.0, "Тест"
        );
        wallet.addTransaction(income);
        
        assertEquals(1000.0, wallet.getBalance(), 0.01);
        assertEquals(1000.0, wallet.getTotalIncome(), 0.01);
        assertEquals(0.0, wallet.getTotalExpenses(), 0.01);
    }

    @Test
    void testAddExpense() {
        Transaction expense = new Transaction(
            Transaction.TransactionType.EXPENSE, "Еда", 500.0, "Тест"
        );
        wallet.addTransaction(expense);
        
        assertEquals(-500.0, wallet.getBalance(), 0.01);
        assertEquals(0.0, wallet.getTotalIncome(), 0.01);
        assertEquals(500.0, wallet.getTotalExpenses(), 0.01);
    }

    @Test
    void testAddCategory() {
        wallet.addCategory("Еда");
        assertTrue(wallet.hasCategory("Еда"));
        assertTrue(wallet.hasCategory("еда")); // Проверка регистронезависимости
    }

    @Test
    void testSetBudget() {
        wallet.setBudget("Еда", 1000.0);
        Category category = wallet.getCategory("Еда");
        assertNotNull(category);
        assertEquals(1000.0, category.getBudget(), 0.01);
    }

    @Test
    void testGetIncomeByCategory() {
        wallet.addTransaction(new Transaction(
            Transaction.TransactionType.INCOME, "Зарплата", 2000.0, ""
        ));
        wallet.addTransaction(new Transaction(
            Transaction.TransactionType.INCOME, "Зарплата", 3000.0, ""
        ));
        
        assertEquals(5000.0, wallet.getIncomeByCategory("Зарплата"), 0.01);
    }

    @Test
    void testGetExpensesByCategory() {
        wallet.addTransaction(new Transaction(
            Transaction.TransactionType.EXPENSE, "Еда", 300.0, ""
        ));
        wallet.addTransaction(new Transaction(
            Transaction.TransactionType.EXPENSE, "Еда", 500.0, ""
        ));
        
        assertEquals(800.0, wallet.getExpensesByCategory("Еда"), 0.01);
    }

    @Test
    void testGetRemainingBudget() {
        wallet.setBudget("Еда", 1000.0);
        wallet.addTransaction(new Transaction(
            Transaction.TransactionType.EXPENSE, "Еда", 300.0, ""
        ));
        
        assertEquals(700.0, wallet.getRemainingBudget("Еда"), 0.01);
    }

    @Test
    void testGetExpensesByCategories() {
        wallet.addTransaction(new Transaction(
            Transaction.TransactionType.EXPENSE, "Еда", 300.0, ""
        ));
        wallet.addTransaction(new Transaction(
            Transaction.TransactionType.EXPENSE, "Развлечения", 500.0, ""
        ));
        
        List<String> categories = Arrays.asList("Еда", "Развлечения");
        assertEquals(800.0, wallet.getExpensesByCategories(categories), 0.01);
    }

    @Test
    void testGetMissingCategories() {
        wallet.addCategory("Еда");
        List<String> categories = Arrays.asList("Еда", "Развлечения", "Транспорт");
        List<String> missing = wallet.getMissingCategories(categories);
        
        assertEquals(2, missing.size());
        assertTrue(missing.contains("Развлечения"));
        assertTrue(missing.contains("Транспорт"));
    }
}



