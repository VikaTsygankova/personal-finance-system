package com.finance.app;

import com.finance.app.service.AuthService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Тесты для класса AuthService
 */
public class AuthServiceTest {
    private AuthService authService;

    @BeforeEach
    void setUp() {
        authService = new AuthService();
    }

    @Test
    void testRegister() {
        assertTrue(authService.register("user1", "password1"));
        assertFalse(authService.register("user1", "password2")); // Дубликат
        assertFalse(authService.register("", "password")); // Пустой логин
        assertFalse(authService.register("user2", "")); // Пустой пароль
    }

    @Test
    void testLogin() {
        authService.register("user1", "password1");
        
        assertTrue(authService.login("user1", "password1"));
        assertTrue(authService.isLoggedIn());
        assertNotNull(authService.getCurrentUser());
        assertEquals("user1", authService.getCurrentUser().getUsername());
        
        assertFalse(authService.login("user1", "wrongpassword"));
        assertFalse(authService.login("nonexistent", "password"));
    }

    @Test
    void testLogout() {
        authService.register("user1", "password1");
        authService.login("user1", "password1");
        assertTrue(authService.isLoggedIn());
        
        authService.logout();
        assertFalse(authService.isLoggedIn());
        assertNull(authService.getCurrentUser());
    }

    @Test
    void testCaseInsensitiveUsername() {
        authService.register("User1", "password1");
        assertTrue(authService.login("user1", "password1"));
        assertTrue(authService.login("USER1", "password1"));
    }
}



